"""Continue unanswered original packets without resubmitting an attempted packet."""
import argparse
import fcntl
import json
from pathlib import Path
import subprocess

import collect
from score import evaluate


BASE = Path(__file__).resolve().parent
RUN = BASE / "run"


class LongerWait:
    @staticmethod
    def run(args, **kwargs):
        # The model-visible command, prompt and settings are unchanged.
        kwargs["timeout"] = 600
        return subprocess.run(args, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=["remaining"])
    parser.parse_args()
    jobs = collect.frozen_jobs()
    expected = str(evaluate(collect.ledger(jobs, {"calibration"}), calibration_only=True)["cutoff"])
    if expected != json.loads((RUN/"calibration_checkpoint.json").read_text())["cutoff_exact"]:
        raise RuntimeError("Calibration cutoff differs")
    collect.subprocess = LongerWait
    with (RUN/"lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for key,packet in jobs.items():
            slug = key.replace("/", "_")
            if key.startswith("test/") and not (RUN/(slug+".start.json")).exists():
                collect.collect(key,packet)
    print("Remaining unique packets complete; no attempted packet was resubmitted.")


if __name__ == "__main__":
    main()
