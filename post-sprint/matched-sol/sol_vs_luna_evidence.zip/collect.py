"""Collect the 60 frozen, synthetic packets via ChatGPT-authenticated Codex CLI."""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

from design import packets
from score import ROLES, evaluate


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "run"
MODEL = "gpt-6.1-sol"
LIMIT = 60


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, data):
    with path.open("x") as f:
        json.dump(data, f, indent=2, default=float, allow_nan=False)
        f.write("\n")


def frozen_jobs():
    frozen = json.loads((ROOT / "freeze.json").read_text())
    for name, sha in frozen["files"].items():
        if digest((ROOT / name).read_bytes()) != sha:
            raise RuntimeError("Frozen file mismatch: " + name)
    jobs = {}
    for split, roles in ROLES.items():
        by_role = {role: packets(split, role) for role in roles}
        for p in range(12):
            for role in roles:
                packet = by_role[role][p]
                key = f"{split}/{role}/{p}"
                mapping = json.dumps(packet["cells"], sort_keys=True, separators=(",", ":")).encode()
                if frozen["packets"][key] != {"prompt_sha256": digest(packet["prompt"].encode()),
                                               "cell_map_sha256": digest(mapping)}:
                    raise RuntimeError("Frozen packet mismatch: " + key)
                jobs[key] = packet
    if len(jobs) != LIMIT:
        raise RuntimeError("Unexpected request count")
    return jobs


def parse_answer(text, cells):
    # Missing, malformed or ambiguous answers are invalid. No repair prompts.
    def unique(pairs):
        if len(dict(pairs)) != len(pairs):
            raise ValueError("duplicate JSON keys")
        return dict(pairs)
    try:
        answers = json.loads(text, object_pairs_hook=unique)
    except ValueError:
        answers = {}
    if not isinstance(answers, dict) or set(answers) - {c["answer_key"] for c in cells}:
        answers = {}
    return [val if val in ("A", "B", "C", "D") else "INVALID"
            for val in (answers.get(c["answer_key"]) for c in cells)]


def collect(key, packet):
    slug = key.replace("/", "_")
    path = RUN / (slug + ".reply.json")
    if path.exists():
        return
    reservations = list(RUN.glob("*.start.json"))
    if len(reservations) >= LIMIT:
        raise RuntimeError("60-request ceiling reached")
    receipt = {"packet": key, "started": utc(), "model_requested": MODEL, "effort": "low",
               "prompt_sha256": digest(packet["prompt"].encode())}
    write_new(RUN / (slug + ".start.json"), receipt)
    env = dict(os.environ)
    for name in ("OPENAI_API_KEY", "OPENAI_BASE_URL", "CODEX_API_KEY"):
        env.pop(name, None)
    with tempfile.TemporaryDirectory(prefix="listener-empty-") as empty:
        cmd = ["codex", "-a", "never", "exec", "--ignore-user-config",
               "--ephemeral", "--skip-git-repo-check", "--json", "--model", MODEL,
               "-c", 'forced_login_method="chatgpt"', "-c", 'model_reasoning_effort="low"',
               "-c", 'web_search="disabled"', "-c", 'project_doc_max_bytes=0',
               "-c", 'developer_instructions="Answer the synthetic routing form directly. Do not use tools or call other agents."',
               "--disable", "apps", "--disable", "plugins", "--disable", "shell_tool",
               "--disable", "unified_exec", "--disable", "multi_agent",
               "--sandbox", "read-only", "-C", empty, "-"]
        proc = subprocess.run(cmd, input=packet["prompt"], cwd=empty, env=env,
                              text=True, capture_output=True, timeout=150)
    events = []
    for line in proc.stdout.splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    complete = [e for e in events if e.get("type") == "turn.completed"]
    items = [e.get("item", {}) for e in events if e.get("type") == "item.completed"]
    answers = [i.get("text", "") for i in items if i.get("type") == "agent_message"]
    unexpected = [i.get("type") for i in items if i.get("type") not in ("agent_message", "reasoning")]
    if proc.returncode or len(complete) != 1 or not answers or unexpected:
        # Keep diagnostics private to the work directory; no automatic retries.
        (RUN / (slug + ".diagnostic.txt")).write_text(proc.stderr + "\n" + proc.stdout)
        raise RuntimeError(f"Stopped at {key}: CLI exit {proc.returncode}, completed turns {len(complete)}, tool items {unexpected}")
    receipt.update(finished=utc(), raw_answer=answers[-1], usage=complete[0].get("usage"),
                   tool_items=unexpected, completed_turns=len(complete))
    receipt["choices"] = parse_answer(receipt["raw_answer"], packet["cells"])
    write_new(path, receipt)
    print(f'{len(list(RUN.glob("*.reply.json")))}/{LIMIT} packet replies saved', flush=True)


def ledger(jobs, splits):
    rows = []
    for key, packet in jobs.items():
        split, role, p = key.split("/")
        if split not in splits:
            continue
        rec = json.loads((RUN / (key.replace("/", "_") + ".reply.json")).read_text())
        if rec["prompt_sha256"] != digest(packet["prompt"].encode()):
            raise RuntimeError("Stored prompt hash mismatch")
        choices = parse_answer(rec["raw_answer"], packet["cells"])
        if choices != rec["choices"]:
            raise RuntimeError("Stored answer mismatch")
        for cell, choice in zip(packet["cells"], choices):
            rows.append(dict(cell, split=split, role=role, packet=int(p), choice=choice))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "calibration", "test"))
    args = parser.parse_args()
    jobs = frozen_jobs()
    if args.stage == "preflight":
        print("60 frozen packet hashes and cell maps verified")
        return
    RUN.mkdir(exist_ok=True)
    with (RUN / "lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.stage == "test":
            checkpoint = json.loads((RUN / "calibration_checkpoint.json").read_text())
            cal = evaluate(ledger(jobs, {"calibration"}), calibration_only=True)
            if checkpoint["cutoff_exact"] != str(cal["cutoff"]):
                raise RuntimeError("Cutoff mismatch")
        for key, packet in jobs.items():
            if key.split("/")[0] == args.stage:
                collect(key, packet)
        cal_only = args.stage == "calibration"
        data = ledger(jobs, {"calibration"} if cal_only else set(ROLES))
        result = evaluate(data, calibration_only=cal_only)
        artifact = "calibration_checkpoint.json" if cal_only else "result.json"
        write_new(RUN / artifact, {"written": utc(), "cutoff_exact": str(result["cutoff"]), "report": result})
        if not cal_only:
            with (RUN / "decisions.jsonl").open("x") as out:
                for row in data:
                    out.write(json.dumps(row) + "\n")
        print(f"{args.stage} complete, cutoff {result['cutoff']}", flush=True)


if __name__ == "__main__":
    main()
