"""Independently re-score raw replies. Usage: python3 -B verify_receipts.py run"""

import argparse
from collections import Counter
from datetime import datetime
from fractions import Fraction
import hashlib
from itertools import product, permutations
import json
from pathlib import Path
from statistics import mean

from design import packets, tasks


ROLES = {"calibration": ("plain1", "plain2"), "test": ("plain1", "plain2", "keyed")}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(raw_answer, expected_keys):
    def unique(fields):
        obj = dict(fields)
        if len(obj) != len(fields):
            raise ValueError("duplicate answer key")
        return obj
    try:
        answers = json.loads(raw_answer, object_pairs_hook=unique)
    except ValueError:
        answers = {}
    if not isinstance(answers, dict) or not set(answers).issubset(expected_keys):
        answers = {}
    return [value if value in ("A", "B", "C", "D") else "INVALID"
            for value in (answers.get(k) for k in expected_keys)]


def compare(value, reported, label):
    # JSON result uses float for fractions. All thresholds below use exact rationals.
    check(float(value) == reported, label)


def verify(run, base):
    frozen = read(base / "freeze.json")
    for name, expected in frozen["files"].items():
        check(sha((base / name).read_bytes()) == expected, f"modified {name}")
    outcomes = {}
    ledger = {}
    windows = {s: [] for s in ROLES}
    usages = Counter()
    expected_slugs = set()
    for split, roles in ROLES.items():
        for role in roles:
            for packet in packets(split, role):
                key = f"{split}/{role}/{packet['packet']}"
                slug = key.replace("/", "_")
                expected_slugs.add(slug)
                config = frozen["packets"][key]
                cell_map = json.dumps(packet["cells"], sort_keys=True, separators=(",", ":")).encode()
                check(config["cell_map_sha256"] == sha(cell_map), f"changed cell map {key}")
                check(config["prompt_sha256"] == sha(packet["prompt"].encode()), f"changed prompt {key}")
                start = read(run / (slug + ".start.json"))
                reply = read(run / (slug + ".reply.json"))
                check(all(reply[k] == v for k, v in start.items()), f"receipt mismatch {key}")
                check((start["packet"], start["prompt_sha256"], start["model_requested"], start["effort"])
                      == (key, config["prompt_sha256"], "gpt-6-luna", "low"), f"configuration {key}")
                check(reply["completed_turns"] == 1 and reply["tool_items"] == [], f"nonconforming turn {key}")
                begin, end = (datetime.fromisoformat(reply[t]) for t in ("started", "finished"))
                check(end >= begin, f"bad timestamps {key}")
                windows[split].append((begin, end))
                usages.update(reply["usage"])
                cells = packet["cells"]
                values = parse(reply["raw_answer"], [c["answer_key"] for c in cells])
                check(values == reply["choices"], f"stored choices disagree {key}")
                for c, value in zip(cells, values):
                    address = (split, role, c["id"], c["zone"], c["arm"], c["wording"])
                    check(address not in outcomes, f"duplicate cell {address}")
                    outcomes[address] = value
                    ledger[address] = dict(c, split=split, role=role, packet=packet["packet"], choice=value)
    for suffix in (".start.json", ".reply.json"):
        check({p.name[:-len(suffix)] for p in run.glob("*" + suffix)} == expected_slugs, "packet inventory")
    check(len(expected_slugs) == 60 and len(outcomes) == 624, "unexpected design size")
    physical = [json.loads(line) for line in (run / "decisions.jsonl").read_text().splitlines()]
    check(len(physical) == len(ledger), "unexpected ledger size")
    for row in physical:
        addr = tuple(row[k] for k in ("split", "role", "id", "zone", "arm", "wording"))
        check(ledger.pop(addr) == row, f"raw answer disagrees with published ledger at {addr}")

    checkpoint = read(run / "calibration_checkpoint.json")
    result = read(run / "result.json")
    report = result["report"]
    freeze_time = datetime.fromisoformat(checkpoint["written"])
    check(max(t[1] for t in windows["calibration"]) <= freeze_time <= min(t[0] for t in windows["test"]),
          "calibration checkpoint outside pre-test window")
    check(datetime.fromisoformat(frozen["created_utc"]) <= min(t[0] for t in windows["calibration"]),
          "input freeze postdates experiment")
    check(max(t[1] for t in windows["test"]) <= datetime.fromisoformat(result["written"]),
          "final report predates test completion")
    check(report["calibration"] == checkpoint["report"]["calibration"], "calibration changed between phases")

    summary = {}
    cutoff = None
    for split, roles in ROLES.items():
        detail = report[split]
        by_id = {row["id"]: row for row in detail["per_task"]}
        cases = tasks(split)
        check(len(cases) == len(by_id) == len(detail["per_task"]) == detail["n_tasks"], "task count")
        check(detail["n_decisions"] == len(cases) * len(roles) * 12, "decision count")
        scores = {}
        public = Counter()
        invalid = Counter()
        key_hits = 0
        null_gaps, code_gaps = [], []
        xs, ws = Counter(), Counter()
        for task in cases:
            tid = task["id"]
            row = by_id[tid]
            for role in roles:
                x = w = paired_correct = task_hits = 0
                for zone, arm, word in product(range(2), range(2), range(3)):
                    val = outcomes[split, role, tid, zone, arm, word]
                    allowed = task["zones"][zone]["routes"]
                    invalid[role] += val == "INVALID"
                    if role == "keyed":
                        task_hits += val == sorted(allowed)[task["flip"] ^ arm]
                    if zone == 0:
                        other = outcomes[split, role, tid, 1, arm, word]
                        paired_correct += val in allowed and other in task["zones"][1]["routes"]
                for zone in (0, 1):
                    for i, j in permutations(range(3), 2):
                        for arm in (0, 1):
                            v = outcomes[split, role, tid, zone, arm, i]
                            w += v != outcomes[split, role, tid, zone, arm, j]
                            x += v != outcomes[split, role, tid, zone, 1 - arm, j]
                xs[role] += Fraction(x, 24)
                ws[role] += Fraction(w, 24)
                scores[role, tid] = Fraction(x - w, 24)
                public[role] += paired_correct
                compare(scores[role, tid], row["sensitivity"][role], f"sensitivity {role} {tid}")
                compare(Fraction(paired_correct, 6), row["public_paired_success"][role], f"routing {role} {tid}")
                if role == "keyed":
                    key_hits += task_hits
                    compare(Fraction(task_hits, 12), row["keyed_adherence"], f"adherence {tid}")
            null_gaps.append(scores["plain1", tid] - scores["plain2", tid])
            compare(null_gaps[-1], row["no_code_gap"], f"null gap {tid}")
            if split == "test":
                code_gaps.append(scores["keyed", tid] - scores["plain2", tid])
                compare(code_gaps[-1], row["code_gap"], f"code gap {tid}")
                check(row["no_code_flag"] == (null_gaps[-1] > cutoff), f"null flag {tid}")
                check(row["code_flag"] == (code_gaps[-1] > cutoff), f"code flag {tid}")
        n = len(cases)
        for role in roles:
            compare(Fraction(public[role], n*6), detail["public_paired_success"][role], f"public {role}")
            compare((xs[role] - ws[role])/n, detail["sensitivity"][role], f"S {role}")
            check(invalid[role] == detail["invalid_by_role"][role], f"invalid {role}")
        compare(mean(null_gaps), detail["mean_no_code_gap"], "mean null gap")
        summary[split] = {r: {"X": str(xs[r]/n), "W": str(ws[r]/n), "paired_public_hits": public[r],
                              "paired_public_total": 6*n, "invalid": invalid[r]} for r in roles}
        if split == "calibration":
            cutoff = max(Fraction(0), max(null_gaps))
            check(str(cutoff) == checkpoint["cutoff_exact"] == result["cutoff_exact"], "exact cutoff differs")
            for field in (detail["cutoff"], checkpoint["report"]["cutoff"], report["cutoff"]):
                compare(cutoff, field, "cutoff")
        else:
            compare(mean(code_gaps), detail["mean_code_gap"], "mean code gap")
            compare(Fraction(key_hits, 12*n), detail["keyed_adherence"], "overall adherence")
            flags = sum(v > cutoff for v in code_gaps), sum(v > cutoff for v in null_gaps)
            check(flags == (detail["code_flags"], detail["no_code_flags"]), "flag totals")
            gates = {"each_listener_public_paired_success_at_least_80pct":
                     all(public[r]*5 >= 6*n*4 for r in roles),
                     "keyed_adherence_at_least_75pct": key_hits*4 >= 12*n*3,
                     "at_least_9_code_flags": flags[0] >= 9, "at_most_2_no_code_flags": flags[1] <= 2}
            check(gates == report["gates"] and all(gates.values()) == report["all_gates_pass"], "gates differ")
            summary.update(cutoff=str(cutoff), code_flags=flags[0], null_flags=flags[1],
                           keyed_hits=key_hits, keyed_total=12*n, gates=gates)
    return dict(request_receipts=60, decisions=len(outcomes), token_usage=dict(usages), **summary)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.run, Path(__file__).resolve().parent), indent=2))
