"""Offline verification and matched comparison. Run with python3 -B compare.py."""
from collections import defaultdict
import json
from pathlib import Path
import subprocess
import sys


BASE = Path(__file__).resolve().parent


def read(p):
    return json.loads(p.read_text())


def check(ok, message):
    if not ok:
        raise ValueError(message)


def extract(base):
    raw = subprocess.check_output([sys.executable, "-B", "verify_receipts.py", "run"], cwd=base)
    verified = json.loads(raw)
    report = read(base/"run/result.json")["report"]
    rows = [json.loads(s) for s in (base/"run/decisions.jsonl").read_text().splitlines()]
    return verified, report, rows


def analyze():
    luna = BASE/"luna"
    fm, fl = read(BASE/"freeze.json"), read(luna/"freeze.json")
    for name in ("design.py", "score.py", "protocol.md"):
        check((BASE/name).read_bytes() == (luna/name).read_bytes(), "changed " + name)
    for name in ("collect.py", "verify_receipts.py"):
        check((BASE/name).read_bytes() == (luna/name).read_bytes().replace(b"gpt-6-luna", b"gpt-6.1-sol"),
              "change beyond the model ID in "+name)
    orig = {k:v for k,v in fl["packets"].items() if k.split("/")[0] in ("calibration","test")}
    check(len(orig) == 60 and fm["packets"] == orig, "prompt or answer-key difference")
    sol_v, sol_r, sol_rows = extract(BASE)
    luna_v, luna_r, luna_rows = extract(luna)
    slug = "test_keyed_6"
    exceptions = BASE / "exceptions"
    replacement = exceptions / "replacement"
    original = read(exceptions / ("original_" + slug + ".start.json"))
    error = read(exceptions / "first_timeout.json")
    retry = read(replacement / (slug + ".reply.json"))
    check(original == error["recorded_start"] and error["type"] == "subprocess.TimeoutExpired", "original attempt")
    for prop in ("packet", "effort", "model_requested", "prompt_sha256"):
        check(original[prop] == retry[prop], "replacement changed " + prop)
    for suffix in (".start.json", ".reply.json"):
        name = slug + suffix
        check(list(replacement.glob("*" + suffix)) == [replacement / name], "replacement inventory")
        check((replacement / name).read_bytes() == (BASE / "run" / name).read_bytes(), "replacement receipt")
    check(max(read(p)["finished"] for p in (BASE/"run").glob("*.reply.json")
              if p.name != slug + ".reply.json") < retry["started"], "replacement timing")
    check(original["started"] < retry["started"], "attempt chronology")
    check([{k:v for k,v in r.items() if k != "choice"} for r in sol_rows] ==
          [{k:v for k,v in r.items() if k != "choice"} for r in luna_rows], "decision cells differed")
    # Surface whether ordinary listeners vary in their tie-breaking, beyond their public-class accuracy.
    from design import tasks
    task_map = {t["id"]:t for t in tasks("test")}
    def tie_variation(rows):
        eligible = defaultdict(set)
        for r in rows:
            if r["split"] == "test" and r["role"] in ("plain1", "plain2"):
                key = (r["role"],r["id"],r["zone"],r["arm"])
                if r["choice"] in task_map[r["id"]]["zones"][r["zone"]]["routes"]:
                    eligible[key].add(r["choice"])
        return {role:sum(k[0]==role and len(v)>1 for k,v in eligible.items()) for role in ("plain1","plain2")}
    def summarize(v, report, rows):
        held = report["test"]
        return {"cutoff_exact":v["cutoff"], "all_gates_pass": report["all_gates_pass"],
                "gates":report["gates"], "public_pairs":{r:d["paired_public_hits"] for r,d in v["test"].items()},
                "public_pairs_per_role":72, "adherence_hits":v["keyed_hits"], "adherence_total":v["keyed_total"],
                "code_flags":v["code_flags"], "no_code_flags":v["null_flags"],
                "eligible_tie_variation_groups_of_48":tie_variation(rows),
                "within_arm_W":{r:d["W"] for r,d in v["test"].items()},
                "cross_arm_X":{r:d["X"] for r,d in v["test"].items()},
                "mean_code_gap":held["mean_code_gap"],"mean_no_code_gap":held["mean_no_code_gap"],
                "invalid":sum(z["invalid"] for s in ("calibration","test") for z in v[s].values()),
                "decisions":v["decisions"],"requests":v["request_receipts"],"usage":v["token_usage"]}
    s, l = sol_r["test"]["per_task"], luna_r["test"]["per_task"]
    paired = []
    for a,b in zip(s,l):
        check(a["id"] == b["id"], "unmatched task")
        paired.append({"case":a["id"], "luna_code_hits_of_12":round(12*b["keyed_adherence"]),
                       "sol_code_hits_of_12":round(12*a["keyed_adherence"]),
                       "luna_gap":b["code_gap"],"sol_gap":a["code_gap"],"luna_flag":b["code_flag"],
                       "sol_flag":a["code_flag"],"luna_null_gap":b["no_code_gap"],"sol_null_gap":a["no_code_gap"],
                       "luna_null_flag":b["no_code_flag"],"sol_null_flag":a["no_code_flag"]})
    retry_rows = [r for r in sol_rows if r["split"]=="test" and r["role"]=="keyed" and r["packet"]==6]
    check(len(retry_rows) == 12, "replacement size")
    return {"matched_prompts":len(orig),"matched_decisions":len(sol_rows),
            "sol_attempts":{"attempted":sol_v["request_receipts"]+1, "completed":sol_v["request_receipts"],
                            "replacement_packet":original["packet"], "timed_out_attempt_usage":None,
                            "replacement_correct":sum(r["choice"]==r["expected_route"] for r in retry_rows),
                            "replacement_decisions":len(retry_rows),"replacement_usage":retry["usage"]},
            "sol":summarize(sol_v,sol_r,sol_rows),
            "luna":summarize(luna_v,luna_r,luna_rows),"paired_test_cases":paired}


if __name__ == "__main__":
    print(json.dumps(analyze(), indent=2))
