"""Send the single authorized replacement for the timed-out informed packet."""
import fcntl
import json

import collect
from transport_recovery import LongerWait


def main():
    key = "test/keyed/6"
    slug = key.replace("/", "_")
    run = collect.RUN
    exceptions = collect.ROOT / "exceptions"
    with (run / "lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        jobs = collect.frozen_jobs()
        expected = {k.replace("/", "_") for k in jobs}
        starts = {p.name.removesuffix(".start.json") for p in run.glob("*.start.json")}
        replies = {p.name.removesuffix(".reply.json") for p in run.glob("*.reply.json")}
        if starts != expected or replies != expected - {slug}:
            raise ValueError("Original call inventory differs from authorized replacement")
        initial = (run / (slug + ".start.json")).read_bytes()
        timeout = json.loads((exceptions / "first_timeout.json").read_text())
        packet = jobs[key]
        if (timeout["recorded_start"] != json.loads(initial)
                or timeout["recorded_start"]["prompt_sha256"] != collect.digest(packet["prompt"].encode())):
            raise ValueError("Timed-out prompt differs")
        replacement = exceptions / "replacement"
        replacement.mkdir(exist_ok=False)
        (exceptions / ("original_" + slug + ".start.json")).write_bytes(initial)
        collect.RUN = replacement
        collect.LIMIT = 1
        collect.subprocess = LongerWait
        collect.collect(key, packet)


if __name__ == "__main__":
    main()
