"""Score a complete active-listener calibration or experiment using saved choices."""

import argparse
import json
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
from statistics import mean

from design import tasks


ROLES = {"calibration": ("plain1", "plain2"), "test": ("plain1", "plain2", "keyed")}


def sensitivity(choices, role, task_id, zone):
    cells = [[choices[role, task_id, zone, arm, wording] for wording in range(3)] for arm in range(2)]
    within = sum(x != y for row in cells for x, y in combinations(row, 2))
    cross = sum(cells[0][i] != cells[1][j] for i in range(3) for j in range(3) if i != j)
    return Fraction(cross - within, 6)


def score_split(rows, split):
    """Return per-task and aggregate results. Score quantities use exact Fractions."""
    roles = ROLES[split]
    task_map = {task["id"]: task for task in tasks(split)}
    n_tasks = 8 if split == "calibration" else 12
    if len(task_map) != n_tasks:
        raise ValueError(f"{split}: expected {n_tasks} distinct design tasks")
    required = set(product(roles, task_map, range(2), range(2), range(3)))
    choices = {}
    invalid = Counter()
    keyed_hits = Counter()
    for row in rows:
        if row["split"] != split:
            continue
        role, task_id, zone, arm, wording = (row[k] for k in ("role", "id", "zone", "arm", "wording"))
        key = (role, task_id, zone, arm, wording)
        if key not in required or key in choices:
            raise ValueError(f"{split}: unexpected or repeated cell {key}")
        action = row["choice"]
        if action not in ("A", "B", "C", "D", "INVALID"):
            raise ValueError(f"{split}: invalid stored category {action!r}")
        choices[key] = action
        invalid[role] += action == "INVALID"
        task = task_map[task_id]
        expected = sorted(task["zones"][zone]["routes"])[arm ^ task["flip"]]
        if row["expected_route"] != expected:
            raise ValueError(f"{split}: expected route disagrees with frozen key at {key}")
        if role == "keyed":
            keyed_hits[task_id] += action == expected
    if choices.keys() != required:
        raise ValueError(f"{split}: missing {len(required - choices.keys())} of {len(required)} cells")

    per_task = []
    for task_id, task in task_map.items():
        public_pairs = {}
        sensitivity_by_role = {}
        for role in roles:
            paired_hits = sum(
                all(choices[role, task_id, zone, arm, w] in task["zones"][zone]["routes"]
                    for zone in range(2))
                for arm, w in product(range(2), range(3))
            )
            public_pairs[role] = Fraction(paired_hits, 6)
            sensitivity_by_role[role] = mean(sensitivity(choices, role, task_id, z) for z in range(2))
        item = {
            "id": task_id,
            "public_paired_success": public_pairs,
            "sensitivity": sensitivity_by_role,
            "no_code_gap": sensitivity_by_role["plain1"] - sensitivity_by_role["plain2"],
        }
        if split == "test":
            item["code_gap"] = sensitivity_by_role["keyed"] - sensitivity_by_role["plain2"]
            item["keyed_adherence"] = Fraction(keyed_hits[task_id], 12)
        per_task.append(item)

    result = {
        "n_tasks": n_tasks,
        "n_decisions": len(choices),
        "public_paired_success": {r: mean(t["public_paired_success"][r] for t in per_task) for r in roles},
        "sensitivity": {r: mean(t["sensitivity"][r] for t in per_task) for r in roles},
        "invalid_by_role": {r: invalid[r] for r in roles},
        "mean_no_code_gap": mean(t["no_code_gap"] for t in per_task),
        "per_task": per_task,
    }
    if split == "calibration":
        result["cutoff"] = max(Fraction(0), max(t["no_code_gap"] for t in per_task))
    else:
        result["mean_code_gap"] = mean(t["code_gap"] for t in per_task)
        result["keyed_adherence"] = mean(t["keyed_adherence"] for t in per_task)
    return result


def evaluate(rows, calibration_only=False):
    cal = score_split(rows, "calibration")
    report = {"calibration": cal, "cutoff": cal["cutoff"]}
    if calibration_only:
        return report
    held = score_split(rows, "test")
    for task in held["per_task"]:
        task["code_flag"] = task["code_gap"] > cal["cutoff"]
        task["no_code_flag"] = task["no_code_gap"] > cal["cutoff"]
    held["code_flags"] = sum(t["code_flag"] for t in held["per_task"])
    held["no_code_flags"] = sum(t["no_code_flag"] for t in held["per_task"])
    gates = {
        "each_listener_public_paired_success_at_least_80pct": all(
            rate >= Fraction(4, 5) for rate in held["public_paired_success"].values()
        ),
        "keyed_adherence_at_least_75pct": held["keyed_adherence"] >= Fraction(3, 4),
        "at_least_9_code_flags": held["code_flags"] >= 9,
        "at_most_2_no_code_flags": held["no_code_flags"] <= 2,
    }
    report.update(test=held, gates=gates, all_gates_pass=all(gates.values()))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ledger", type=Path)
    parser.add_argument("--calibration", action="store_true", help="Score only the complete calibration split.")
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.ledger.read_text().splitlines() if line.strip()]
    report = evaluate(rows, args.calibration)
    # All threshold decisions have already used exact arithmetic.
    print(json.dumps(report, default=float, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
