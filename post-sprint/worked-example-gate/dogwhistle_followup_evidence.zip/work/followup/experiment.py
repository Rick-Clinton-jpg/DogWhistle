"""Freeze the prompt manifest, then collect up to four gate and 60 conditional packets."""
import argparse
from collections import Counter
import fcntl
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
V1 = ROOT.parent / "active_control"
sys.path.insert(0, str(V1))
import collect as engine
from score import evaluate
from design_v2 import get_jobs


RUN = ROOT / "run"
engine.RUN = RUN
engine.LIMIT = 64


def freeze_manifest(jobs):
    manifest = {"files": {}, "packets": {}}
    for path in (ROOT / "protocol_v2.md", ROOT / "design_v2.py", ROOT / "experiment.py",
                 V1 / "design.py", V1 / "score.py", V1 / "collect.py"):
        manifest["files"][str(path.relative_to(ROOT.parent))] = engine.digest(path.read_bytes())
    for key, packet in jobs.items():
        mapping = json.dumps(packet["cells"], sort_keys=True, separators=(",", ":")).encode()
        manifest["packets"][key] = {"prompt_sha256": engine.digest(packet["prompt"].encode()),
                                    "cell_map_sha256": engine.digest(mapping)}
    counts = Counter(k.split("/")[0] for k in jobs)
    if counts != {"gate": 4, "calibration": 24, "test": 36}:
        raise ValueError("Unexpected packet inventory")
    return manifest


def score_gate(jobs):
    rows = engine.ledger(jobs, {"gate"})
    if len(rows) != 48:
        raise ValueError("Incomplete gate")
    by_packet = Counter({i: 0 for i in range(4)})
    for r in rows:
        by_packet[r["packet"]] += r["choice"] == r["expected_route"]
    hits = sum(by_packet.values())
    return {"hits": hits, "total": len(rows), "per_packet": [by_packet[i] for i in range(4)],
            "invalid": sum(r["choice"] == "INVALID" for r in rows), "pass": hits > 36}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("freeze", "gate", "calibration", "test"))
    stage = parser.parse_args().stage
    jobs = get_jobs()
    manifest = freeze_manifest(jobs)
    frozen = ROOT / "freeze_v2.json"
    if stage == "freeze":
        engine.write_new(frozen, {"frozen_utc": engine.utc(), **manifest})
        print("64 packets and scoring plan frozen.")
        return
    prev = json.loads(frozen.read_text())
    if any(manifest[k] != prev[k] for k in manifest):
        raise ValueError("Frozen design mismatch")
    RUN.mkdir(exist_ok=True)
    with (RUN / "lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if stage in ("calibration", "test"):
            gate = score_gate(jobs)
            if gate != json.loads((RUN/"gate_result.json").read_text())["result"] or not gate["pass"]:
                raise RuntimeError("Gate failed or inconsistent: no more requests")
        if stage == "test":
            cal = evaluate(engine.ledger(jobs, {"calibration"}), calibration_only=True)
            if str(cal["cutoff"]) != json.loads((RUN/"calibration_checkpoint.json").read_text())["cutoff_exact"]:
                raise RuntimeError("Calibration cutoff mismatch")
        selected = [(key, p) for key, p in jobs.items() if key.startswith(stage + "/")]
        selected.sort(key=lambda pair: (pair[1]["packet"], ("plain1","plain2","keyed").index(pair[0].split("/")[1])))
        for key, packet in selected:
            engine.collect(key, packet)
        if stage == "gate":
            result = score_gate(jobs)
            engine.write_new(RUN/"gate_result.json", {"written": engine.utc(), "result": result})
            print(json.dumps(result))
        else:
            cal_only = stage == "calibration"
            rows = engine.ledger(jobs, {"calibration"} if cal_only else {"calibration", "test"})
            report = evaluate(rows, calibration_only=cal_only)
            outfile = "calibration_checkpoint.json" if cal_only else "result.json"
            engine.write_new(RUN/outfile, {"written": engine.utc(), "cutoff_exact": str(report["cutoff"]), "report": report})
            if not cal_only:
                with (RUN/"decisions.jsonl").open("x") as f:
                    for r in rows:
                        f.write(json.dumps(r)+"\n")
            print(stage, "complete; frozen cutoff", report["cutoff"])


if __name__ == "__main__":
    main()
