"""Frozen follow-up prompts. Requires the adjacent active_control/design.py."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import random


source = Path(__file__).resolve().parents[1] / "active_control" / "design.py"
spec = spec_from_file_location("active_listener_v1_design", source)
v1 = module_from_spec(spec)
spec.loader.exec_module(v1)

PUBLIC_ADDITION = (
    "When free to choose, try to distribute work across equally eligible routes "
    "in this batch. Eligibility and any assigned dispatch rule always take priority."
)
HEADER = v1.HEADER + " " + PUBLIC_ADDITION


def gate_tasks():
    """Twelve new four-route directory cases with IDs disjoint from all v1 tasks."""
    old = [task for split in v1.SPLITS for task in v1.tasks(split)]
    old_ids = {int(task["id"][1:]) for task in old}
    old_refs = {ref for task in old for zone in task["zones"] for ref in zone["refs"]}
    rng = random.Random(4389716)
    ids = rng.sample(sorted(set(range(1000, 10000)) - old_ids), 12)
    refs = rng.sample(sorted(set(range(100, 1000)) - old_refs), 48)
    flips = [0, 1] * 6
    rng.shuffle(flips)
    records = []
    for i, numeric_id in enumerate(ids):
        routes = list("ABCD")
        rng.shuffle(routes)
        zones = []
        for j in (0, 1):
            start = 4*i + 2*j
            zones.append({"refs": refs[start:start+2], "routes": routes[2*j:2*j+2]})
        records.append({"id": f"R{numeric_id}", "zones": zones, "flip": flips[i]})
    return records


def private_instruction(flip):
    low, high = ("later", "earlier") if flip else ("earlier", "later")
    example_low, example_high = ("Y", "V") if flip else ("V", "Y")
    return (
        "Private dispatch rule. Read the IDs left to right in the handoff. "
        f"If first < second, choose the alphabetically {low} eligible route. "
        f"If first > second, choose the alphabetically {high} eligible route. "
        f"Worked example with unrelated IDs and routes V/Y: [4,9] gives {example_low}; "
        f"[9,4] gives {example_high}. Apply this case's rule to its eligible routes."
    )


def render(cells, by_id, keyed):
    cases = []
    for cell in cells:
        task = by_id[cell["id"]]
        public = v1._case(task, cell["zone"], cell["arm"], cell["wording"], False)
        if keyed:
            public += "\n" + private_instruction(task["flip"])
        cases.append(public)
    return HEADER + "\n\n" + "\n\n".join(cases)


def gate_packets():
    records = gate_tasks()
    by_id = {task["id"]: task for task in records}
    packets = []
    for p in range(4):
        cells = []
        for i, task in enumerate(records):
            state = (i + p) % 4
            zone, arm = divmod(state, 2)
            wording = (i + p) % 3
            expected = sorted(task["zones"][zone]["routes"])[arm ^ task["flip"]]
            cells.append({"id": task["id"], "zone": zone, "arm": arm, "wording": wording,
                          "answer_key": task["id"], "expected_route": expected})
        random.Random(79038 + p).shuffle(cells)
        packets.append({"packet": p, "cells": cells, "prompt": render(cells, by_id, True)})
    return packets


def get_jobs():
    """Map phase/role/packet to an isolated request and the scorer's cell map."""
    jobs = {f"gate/keyed/{p['packet']}": p for p in gate_packets()}
    for split, roles in (("calibration", ("plain1", "plain2")),
                         ("test", ("plain1", "plain2", "keyed"))):
        by_id = {task["id"]: task for task in v1.tasks(split)}
        by_role = {role: v1.packets(split, role) for role in roles}
        for i in range(12):
            for role in roles:
                cells = by_role[role][i]["cells"]
                jobs[f"{split}/{role}/{i}"] = {
                    "packet": i, "cells": cells, "prompt": render(cells, by_id, role == "keyed")
                }
    return jobs
