"""Verify the archived failed gate offline. Run: python3 -B work/followup/verify_gate.py"""
from collections import Counter, defaultdict
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
from design_v2 import get_jobs, gate_tasks


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify():
    root = Path(__file__).resolve().parent
    run = root / "run"
    frozen = json.loads((root / "freeze_v2.json").read_text())
    for name, signature in frozen["files"].items():
        require(sha256((root.parent / name).read_bytes()).hexdigest() == signature, name)
    jobs = get_jobs()
    require(jobs.keys() == frozen["packets"].keys(), "packet inventory")
    for key, packet in jobs.items():
        mapping = json.dumps(packet["cells"], sort_keys=True, separators=(",", ":")).encode()
        require(frozen["packets"][key] == {
            "prompt_sha256": sha256(packet["prompt"].encode()).hexdigest(),
            "cell_map_sha256": sha256(mapping).hexdigest()}, key)
    tasks = {t["id"]: t for t in gate_tasks()}
    counts, usage = Counter(), Counter()
    hits = [0] * 4
    endtimes = []
    pairs = defaultdict(dict)
    expected_slugs = {f"gate_keyed_{i}" for i in range(4)}
    for suffix in (".start.json", ".reply.json"):
        require({p.name[:-len(suffix)] for p in run.glob("*" + suffix)} == expected_slugs, "extra/missing requests")
    for i in range(4):
        key, slug = f"gate/keyed/{i}", f"gate_keyed_{i}"
        packet = jobs[key]
        start, reply = [json.loads((run / (slug + suffix)).read_text()) for suffix in (".start.json", ".reply.json")]
        require(all(reply[k] == v for k, v in start.items()), "receipt mismatch")
        require(start["packet"] == key and start["prompt_sha256"] == frozen["packets"][key]["prompt_sha256"], key)
        require((reply["model_requested"], reply["effort"], reply["completed_turns"], reply["tool_items"]) ==
                ("gpt-6-luna", "low", 1, []), "request configuration")
        end = datetime.fromisoformat(reply["finished"])
        require(datetime.fromisoformat(frozen["frozen_utc"]) <= datetime.fromisoformat(start["started"]) <= end, "timing")
        endtimes.append(end)
        answer = json.loads(reply["raw_answer"])
        require(set(answer) == {c["answer_key"] for c in packet["cells"]}, "raw answer identifiers")
        require([answer[c["answer_key"]] for c in packet["cells"]] == reply["choices"], "raw choices")
        usage.update(reply["usage"])
        for c in packet["cells"]:
            task = tasks[c["id"]]
            routes = task["zones"][c["zone"]]["routes"]
            correct = sorted(routes)[c["arm"] ^ task["flip"]]
            require(correct == c["expected_route"], "answer key mismatch")
            choice = answer[c["answer_key"]]
            hits[i] += choice == correct
            counts["eligible"] += choice in routes
            counts["valid"] += choice in ("A","B","C","D")
            pair = pairs[(c["id"], c["zone"])]
            require(c["arm"] not in pair, "repeated arm")
            pair[c["arm"]] = choice, correct
    require(len(pairs) == 24 and all(set(p) == {0,1} for p in pairs.values()), "incomplete paired design")
    for pair in pairs.values():
        (a, x), (b, y) = pair[0], pair[1]
        require(x != y, "private choice must reverse")
        counts["same_choice_on_reversal"] += a == b
        counts["correct_on_both_orders"] += a == x and b == y
    record = json.loads((run / "gate_result.json").read_text())
    require(record["result"] == {"hits": sum(hits), "total":48, "per_packet": hits,
                                 "invalid":48-counts["valid"], "pass":sum(hits)>36}, "gate result")
    require(not record["result"]["pass"] and max(endtimes) <= datetime.fromisoformat(record["written"]), "stop rule")
    return {"requests":4, "per_packet_hits":hits, "correct":sum(hits), "total":48,
            **counts, "usage":dict(usage), "conditional_requests":0}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
