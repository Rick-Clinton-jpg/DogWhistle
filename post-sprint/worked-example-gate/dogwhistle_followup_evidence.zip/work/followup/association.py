"""Descriptive correlations for the first active-listener pilot. Stdlib only."""
import csv
from fractions import Fraction
import json
import math
from pathlib import Path
from statistics import mean
import sys

ROOT = Path(__file__).resolve().parents[2]
PILOT = ROOT / "work/active_control"
sys.path.insert(0, str(PILOT))
from score import sensitivity


def midranks(values):
    return [
        sum(v < value for v in values) + (sum(v == value for v in values) + 1) / 2
        for value in values
    ]


def pearson(x, y):
    xbar, ybar = mean(x), mean(y)
    numerator = sum((a - xbar) * (b - ybar) for a, b in zip(x, y))
    denominator = math.sqrt(sum((a - xbar)**2 for a in x) * sum((b - ybar)**2 for b in y))
    return float(numerator) / denominator if denominator else math.nan


def correlations(rows, xkey="adherence", ykey="gap"):
    x = [r[xkey] for r in rows]
    y = [r[ykey] for r in rows]
    return pearson(x, y), pearson(midranks(x), midranks(y))


def make_tables():
    rows = [json.loads(line) for line in (PILOT / "run/decisions.jsonl").read_text().splitlines()]
    held = [r for r in rows if r["split"] == "test"]
    choices = {(r["role"], r["id"], r["zone"], r["arm"], r["wording"]): r["choice"] for r in held}
    assert len(held) == len(choices) == 432
    zones, cases, opposite = [], [], []
    verified = {r["id"]: r for r in json.loads((PILOT / "run/result.json").read_text())["report"]["test"]["per_task"]}
    for case_id in sorted(verified):
        pair = []
        for zone in (0, 1):
            keyed = [r for r in held if r["role"] == "keyed" and r["id"] == case_id and r["zone"] == zone]
            assert len(keyed) == 6
            hits = sum(r["choice"] == r["expected_route"] for r in keyed)
            sk = sensitivity(choices, "keyed", case_id, zone)
            so = sensitivity(choices, "plain2", case_id, zone)
            pair.append(dict(case=case_id, public_state=zone, code_hits=hits, code_choices=6,
                             adherence=Fraction(hits, 6), keyed_s=sk, outsider_s=so, gap=sk - so))
        for row, other in zip(pair, reversed(pair)):
            opposite.append(dict(case=case_id, public_state=row["public_state"],
                                 adherence=row["adherence"], gap=other["gap"]))
        zones.extend(pair)
        merged = dict(case=case_id, code_hits=sum(r["code_hits"] for r in pair), code_choices=12)
        for k in ("adherence", "keyed_s", "outsider_s", "gap"):
            merged[k] = mean(r[k] for r in pair)
        assert float(merged["gap"]) == verified[case_id]["code_gap"]
        assert float(merged["adherence"]) == verified[case_id]["keyed_adherence"]
        cases.append(merged)
    return cases, zones, opposite


def wording_holdouts():
    rows = [json.loads(line) for line in (PILOT / "run/decisions.jsonl").read_text().splitlines()]
    lookup = {(r["id"],r["zone"],r["role"],r["arm"],r["wording"]):r for r in rows if r["split"]=="test"}
    case_ids = sorted({k[0] for k in lookup})
    results = []
    for w in range(3):
        p,q = [i for i in range(3) if i != w]
        split = []
        for case in case_ids:
            for zone in (0,1):
                def reduced_s(role):
                    vals = [[lookup[case,zone,role,arm,v]["choice"] for v in (p,q)] for arm in (0,1)]
                    (a,b),(c,d) = vals
                    return Fraction((a!=d)+(b!=c)-(a!=b)-(c!=d),2)
                held = [lookup[case,zone,"keyed",arm,w] for arm in (0,1)]
                split.append(dict(adherence=Fraction(sum(r["choice"]==r["expected_route"] for r in held),2),
                                  gap=reduced_s("keyed")-reduced_s("plain2")))
        results.append(correlations(split))
    return results


def main():
    cases, zones, opposite = make_tables()
    for name, rows in [("cases",cases), ("public_states", zones)]:
        with (ROOT / f"outputs/active_listener_association_{name}.csv").open("w", newline="") as out:
            writer = csv.DictWriter(out, fieldnames=list(rows[0]))
            writer.writeheader()
            for row in rows:
                writer.writerow({k:round(float(v), 9) if isinstance(v, Fraction) else v for k,v in row.items()})
    subsets = [("case means", cases), ("all case states", zones), ("public state 0", zones[::2]),
               ("public state 1", zones[1::2]), ("one-state adherence vs other-state D", opposite),
               ("state 0 adherence vs state 1 D", opposite[::2]), ("state 1 adherence vs state 0 D", opposite[1::2])]
    for label, rows in subsets:
        print(label, "n=", len(rows), *(round(x, 4) for x in correlations(rows)))
    print("all outsider state scores zero:", all(r["outsider_s"] == 0 for r in zones))
    loo = [correlations([r for r in cases if r["case"] != row["case"]]) for row in cases]
    print("leave-one-case-out Pearson and Spearman", [(min(col), max(col)) for col in zip(*loo)])
    delta = [{"adherence":a["adherence"]-b["adherence"],"gap":a["gap"]-b["gap"]} for a,b in zip(zones[::2],zones[1::2])]
    print("within-case state-0 minus state-1 deltas", correlations(delta))
    print("each wording held out for adherence", wording_holdouts())
    print("hits bins", [(n, len(group), float(mean(r["gap"] for r in group)))
                         for n in sorted({r["code_hits"] for r in zones})
                         for group in [[r for r in zones if r["code_hits"] == n]]])


if __name__ == "__main__":
    main()
